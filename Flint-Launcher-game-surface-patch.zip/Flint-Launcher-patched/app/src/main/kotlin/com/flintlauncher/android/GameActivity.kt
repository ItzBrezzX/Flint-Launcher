package com.flintlauncher.android

import android.app.Activity
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Bundle
import android.system.Os
import android.util.Log
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import com.flintlauncher.android.nativebridge.NativeBridge
import com.flintlauncher.android.runtime.LaunchRequest
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Full-screen Minecraft host activity.
 *
 * Owns the Android Surface, creates the EGL context, initializes GL4ES + GLFW,
 * then starts the in-process JVM on a dedicated worker. This mirrors the
 * Mojo/Pojav surface-before-JVM order while keeping Flint package identity.
 */
class GameActivity : Activity(), SurfaceHolder.Callback {

    private lateinit var surfaceView: SurfaceView
    private lateinit var statusView: TextView
    private var setupThread: Thread? = null
    private val launchStarted = AtomicBoolean(false)
    private var surfaceWidth = 0
    private var surfaceHeight = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (PendingLaunchStore.peek() == null) {
            finishWithError("No prepared Minecraft launch is waiting.")
            return
        }
        if (!NativeBridge.isNativeLoaded) {
            finishWithError(
                "Native library not loaded: " + (NativeBridge.nativeLoadError ?: "unknown"),
            )
            return
        }

        surfaceView = SurfaceView(this).apply {
            holder.setFormat(PixelFormat.RGBA_8888)
            holder.addCallback(this@GameActivity)
            isFocusable = true
            isFocusableInTouchMode = true
        }
        statusView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xB9000000.toInt())
            text = "Preparing Android surface for Minecraft…"
        }

        setContentView(
            FrameLayout(this).apply {
                addView(
                    surfaceView,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT,
                    ),
                )
                addView(
                    statusView,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        Gravity.TOP or Gravity.START,
                    ),
                )
            },
        )
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        if (setupThread?.isAlive == true) return
        val thread = Thread({ prepareAndLaunch(holder) }, "Flint-Game-Setup")
        setupThread = thread
        thread.start()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfaceWidth = width
        surfaceHeight = height
        if (width > 0 && height > 0) {
            runCatching { NativeBridge.nativeResizeWindowSurface(width, height) }
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        runCatching { NativeBridge.nativeGlfwSetWindowShouldClose(true) }
        runCatching { NativeBridge.nativeDestroyWindowSurface() }
    }

    private fun prepareAndLaunch(holder: SurfaceHolder) {
        val request = PendingLaunchStore.take()
        if (request == null) {
            finishWithError("Launch request disappeared before the surface was ready.")
            return
        }
        try {
            setStatus("Creating EGL window surface…")
            val eglStatus = NativeBridge.nativeCreateWindowSurface(holder.surface)
            if (eglStatus != "egl-window-ready") {
                throw IllegalStateException("EGL window surface failed: $eglStatus")
            }

            val width = surfaceWidth.takeIf { it > 0 } ?: surfaceView.width.takeIf { it > 0 } ?: 1280
            val height = surfaceHeight.takeIf { it > 0 } ?: surfaceView.height.takeIf { it > 0 } ?: 720
            NativeBridge.nativeResizeWindowSurface(width, height)

            setStatus("Loading GL4ES…")
            val glPath = File(applicationInfo.nativeLibraryDir, "libGL.so").absolutePath
            if (!NativeBridge.nativeLoadGL4ES(glPath)) {
                throw IllegalStateException("GL4ES failed to initialize on the current EGL context ($glPath)")
            }

            setStatus("Attaching Flint GLFW backend…")
            if (!NativeBridge.nativeGlfwAttachAndroidSurface(width, height)) {
                throw IllegalStateException("GLFW could not attach the Android EGL surface")
            }
            if (!NativeBridge.nativeGlfwInitialize()) {
                throw IllegalStateException("glfwInit failed after Android surface attach")
            }
            if (!NativeBridge.nativeGlfwCreateWindow(width, height, "Minecraft")) {
                throw IllegalStateException("glfwCreateWindow failed for the Android surface")
            }

            applyProcessEnvironment(request)

            setStatus("Starting Minecraft JVM (offline path)…")
            if (!launchStarted.compareAndSet(false, true)) return
            startJvm(request)
        } catch (error: Throwable) {
            val message = error.message ?: error.javaClass.simpleName
            Log.e(TAG, "Game surface setup failed", error)
            PendingLaunchStore.reportError(message)
            finishWithError(message)
        }
    }

    private fun applyProcessEnvironment(request: LaunchRequest) {
        val nativeLibDir = applicationInfo.nativeLibraryDir
        val jreHome = request.runtime.homeDir.absolutePath
        val jreLibCandidates = listOf(
            File(request.runtime.homeDir, "lib"),
            File(request.runtime.homeDir, "lib/aarch64"),
            File(request.runtime.homeDir, "lib/arm"),
            File(request.runtime.homeDir, "lib/x86_64"),
            File(request.runtime.homeDir, "lib/i386"),
            File(request.runtime.homeDir, "lib/server"),
            File(request.runtime.homeDir, "lib/jli"),
        ).filter { it.isDirectory }.map { it.absolutePath }

        val pathParts = buildList {
            add(request.nativeDir.absolutePath)
            add(nativeLibDir)
            addAll(jreLibCandidates)
            System.getenv("LD_LIBRARY_PATH")?.let { add(it) }
        }.distinct()
        val ldPath = pathParts.joinToString(":")

        fun put(key: String, value: String) {
            try {
                Os.setenv(key, value, true)
            } catch (error: Throwable) {
                Log.w(TAG, "Os.setenv($key) failed: ${error.message}")
            }
        }

        put("LD_LIBRARY_PATH", ldPath)
        put("JAVA_HOME", jreHome)
        put("LIBGL_ES", "2")
        put("LIBGL_MIPMAP", "3")
        put("LIBGL_NOERROR", "1")
        put("MESA_GL_VERSION_OVERRIDE", "3.2")
        put("MESA_GLSL_VERSION_OVERRIDE", "150")
        // Help LWJGL find staged Android natives
        put("org.lwjgl.librarypath", request.nativeDir.absolutePath)
    }

    private fun startJvm(request: LaunchRequest) {
        val worker = Thread({
            try {
                if (!NativeBridge.nativeLoadJre(request.runtime.homeDir.absolutePath)) {
                    throw IllegalStateException(
                        "Failed to load libjli from ${request.runtime.homeDir.absolutePath}",
                    )
                }
                val args = mutableListOf<String>()
                args += "java"
                args += request.jvmArgs
                if (request.jvmArgs.none { it == "-cp" || it == "-classpath" }) {
                    args += "-cp"
                    args += request.classpath.joinToString(File.pathSeparator) { it.absolutePath }
                }
                args += request.mainClass
                args += request.gameArgs

                setStatus(
                    "JLI_Launch ${request.versionId} as ${request.accountUsername} " +
                        "(userType=${request.userType})…",
                )
                val code = NativeBridge.nativeLaunchJvm(args.toTypedArray())
                setStatus("Minecraft JVM returned exit code $code")
                if (code != 0) {
                    PendingLaunchStore.reportError("Minecraft JVM exited with code $code")
                }
            } catch (error: Throwable) {
                val message = error.message ?: error.javaClass.simpleName
                Log.e(TAG, "JVM launch failed", error)
                PendingLaunchStore.reportError(message)
                setStatus("Launch failed: $message")
            }
        }, "Flint-Minecraft-JVM")
        worker.isDaemon = false
        worker.start()
    }

    private fun setStatus(text: String) {
        Log.i(TAG, text)
        runOnUiThread { statusView.text = text }
    }

    private fun finishWithError(message: String) {
        setStatus(message)
        runOnUiThread {
            statusView.text = message
            // Keep the activity visible briefly so the user can read the error.
            statusView.postDelayed({ finish() }, 2500)
        }
    }

    override fun onDestroy() {
        runCatching { NativeBridge.nativeGlfwSetWindowShouldClose(true) }
        runCatching { NativeBridge.nativeShutdown() }
        super.onDestroy()
    }

    companion object {
        private const val TAG = "FlintGameActivity"
    }
}
