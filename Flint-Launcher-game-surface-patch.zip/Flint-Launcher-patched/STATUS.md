# Snapshot status: INCOMPLETE — surface launch path added

Microsoft authentication remains paused (offline first).

## Added from Mojo study (Flint identity kept)

- `GameActivity`: Surface → EGL (`egl-window-ready`) → GL4ES → GLFW attach/init/window → process env → JLI_Launch.
- `PendingLaunchStore`: hand-off of prepared `LaunchRequest` from coordinator to GameActivity.
- `PlayLaunchCoordinator` starts `GameActivity` after install/runtime/natives staging instead of calling JLI without a surface.
- Manifest registers `GameActivity` (landscape, fullscreen).
- Environment: `LD_LIBRARY_PATH`, `JAVA_HOME`, `LIBGL_ES`, LWJGL library path (Android `Os.setenv`).

## Still required on device (you build APK)

- Successful `:native` + `:app` build with real `libGL.so` / `libglfw.so` / `libflint_native.so`.
- Mobile JRE download/verify.
- Confirm title screen and world load.
- Touch/mouse polish beyond basic surface input queue.

READY TO PLAY: no (not device-verified).
